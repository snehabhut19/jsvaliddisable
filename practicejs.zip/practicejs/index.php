<html>
<head>
    <title> signup form </title>

    <!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css">
<link rel="stylesheet" href="style.css">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
<!-- js link -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js" integrity="sha512-894YE6QWD5I59HgZOGReFYm4dnWc1Qt5NtvYSaNcOP+u1T9qYdvdihz0PPSiiqn/+/3e7Jo4EaG7TubfWGUrMQ==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>


<!-- <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script> -->

  
  <style>
      .error{
          color : red;
      }
      </style>
</head>

<body>
<section class="vh-100 gradient-custom">
  <div class="container py-5 h-100">
    <div class="row justify-content-center align-items-center h-100">
      <div class="col-12 col-lg-9 col-xl-7">
        <div class="card shadow-2-strong card-registration" style="border-radius: 15px;">
          <div class="card-body p-4 p-md-5">
            <h3 class="mb-4 pb-2 pb-md-0 mb-md-5">Registration Form</h3>
            <form  name="reg" action="connect.php" onsubmit="return validateForm()" id="frm" method="post" class="form" enctype="multipart/form-data">

              <div class="row">
                <div class="col-md-6 mb-4">

                  <div class="form-outline">
                    <input type="text" id="name" class="form-control form-control-lg" name="name"/>
                    <label class="form-label" for="name"> Name</label>
                    <p id="f" class="error"></p>
                  </div>

                </div>
                <div class="col-md-6 mb-4">

                  <div class="form-outline">
                    <input type="text" id="email" class="form-control form-control-lg"  name="email"/>
                    <label class="form-label" for="email">email</label>
                    <p id="e" class="error"></p>
                  </div>

                </div>
              </div>

              <div class="row">
                <div class="col-md-6 mb-4 d-flex align-items-center"  >

                  <div class="form-outline datepicker w-100">
                    <input
                      type="password"
                      class="form-control form-control-lg"
                      id="password"
                      name="password"
                      oninput="undisablePsw()"
                    />
                    <label for="password" class="form-label">password</label>
                    <p id="p" class="error"></p>
                  </div>

                  <!-- <div class="col-md-6 mb-4 d-flex align-items-center"> -->

                  <div class="form-outline datepicker w-100" >
                    <input
                      type="password"
                      class="form-control form-control-lg"
                      id="conpass"
                      name="conpass"
                    />
                    <label for="password" class="form-label">con-pass</label>
                    <p id="cp" class="error"></p>
                  </div>

                </div>
                <div class="col-md-6 mb-4">

                  <h6 class="mb-2 pb-1">Gender: </h6>

                  <div class="form-check form-check-inline">
                    <input
                      class="form-check-input"
                      type="radio"
                      name="gender"
                      id="gender"
                      value="female"
                     
                    />
                    <label class="form-check-label" for="female">female</label>
                  </div>

                  <div class="form-check form-check-inline">
                    <input
                      class="form-check-input"
                      type="radio"
                      name="gender"
                      id="gender"
                      value="male"
                    />
                    <label class="form-check-label" for="gender">male</label>
                  </div>

                  <div class="form-check form-check-inline">
                    <input
                      class="form-check-input"
                      type="radio"
                      name="gender"
                      id="gender"
                      value="other"
                    />
                    <label class="form-check-label" for="other">other</label>
                    <p id="g" class="error"></p>
                  </div>

                </div>
              </div>

              <div class="row">
                <div class="col-md-6 mb-4 pb-2">

                  <div class="form-outline">
                    <input type="text" id="phone" class="form-control form-control-lg" name="phone" />
                    <label class="form-label" for="phone">phone number</label>
                    <p id="ph" class="error"></p>
                  </div>

                </div>
                <div class="col-md-6 mb-4 pb-2">

                  <div class="form-outline">
                  <label>ADDRESS :</label>
                    <textarea name="address" id="address"></textarea>
                    <p id="a" class="error"></p>
                  </div>

                </div>
              </div>

              <div class="row">
                <div class="col-12">

                <label>CITY : </label>
                    <select id="city" name="city">
                   
                    <option value="select">select city</option>
                    <option value="rajkot">rajkot</option>
                    <option value="ahmedabad">ahmedabad</option>
                    <option value="surat"> surat</option>
                    </select>
                    <p id="ci" class="error"></p>
                </div>
              </div>

              <div class="row">
                <div class="col">
                    <label>HOBBIES :</label>
                    <input type="checkbox" id="hobbies1" name="hobbies[]" value="reading" class="h">reading
                    <input type="checkbox" id="hobbies2" name="hobbies[]" value="writting" class="h">writting
                    <p id="h" class="error"></p>
                </div>

                <div class="col">
                    <label>FILE :</label>
                    <input type="file" id="file" name="file" >
                    <p id="fi" class="error"></p>
                </div>
            </div>

            <br>

            <div>
            <div>
                    <input type="checkbox" name="checkbox" id="checkbox">email me
                </div>

              <div class="mt-4 pt-2">
                <input class="btn btn-primary btn-lg" type="submit" value="Submit" id="submit" name="submit"/>
              </div>

            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous">
</script>
<script src="js/index.js"></script>
<script>
   var x = document.getElementById("conpass").disabled = true;
   
//    function undisablePsw() {
//   var password = document.getElementById('password').value;

//   if(password.length <= 0)
//   {
//     document.getElementById("conpass").disabled = true;
//   }else{
//     document.getElementById("conpass").disabled = false;
//   }

// }


  </script>


</body>
</html>
